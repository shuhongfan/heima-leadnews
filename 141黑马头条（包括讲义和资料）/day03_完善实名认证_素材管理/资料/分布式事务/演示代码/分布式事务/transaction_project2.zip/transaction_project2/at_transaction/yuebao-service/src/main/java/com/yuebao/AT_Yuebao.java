package com.yuebao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @作者 itcast
 * @创建日期 2020/7/23 16:35
 **/
@SpringBootApplication
public class AT_Yuebao {
    public static void main(String[] args) {
        SpringApplication.run(AT_Yuebao.class,args);
    }
}
