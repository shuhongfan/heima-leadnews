package com.itcast.mq.yuebao.rabbitconfig;

/**
 * @作者 itcast
 * @创建日期 2020/7/24 10:35
 **/
public class RabbitmqSender {
}
